//
//  B_B_ViewController.m
//  iOS-rotate-demo
//
//  Created by 郑亚伟 on 16/10/14.
//  Copyright © 2016年 Dvel. All rights reserved.
//

#import "B_B_ViewController.h"

@interface B_B_ViewController ()

@end

@implementation B_B_ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    self.view.backgroundColor = [UIColor whiteColor];
}
@end
