//
//  A_A_ViewController.m
//  iOS-rotate-demo
//
//  Created by 郑亚伟 on 16/10/14.
//  Copyright © 2016年 Dvel. All rights reserved.
//

#import "A_A_ViewController.h"
#import "AppDelegate.h"


@interface A_A_ViewController ()

@end

@implementation A_A_ViewController
//相当于全屏播放页面
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 100, 100)];
    label.text = @"assss";
    [self.view addSubview:label];
    
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    appDelegate.allowRotation = 1;
    
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //离开的时候要再次设置
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    appDelegate.allowRotation = 0;
    
    [self dismissViewControllerAnimated:YES completion:nil];
}



//是否可以旋转
//- (BOOL)shouldAutorotate
//{
//    return YES;
//}


//在这里布局横竖屏的UI
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    if (toInterfaceOrientation == UIInterfaceOrientationPortrait) {
        self.view.backgroundColor = [UIColor whiteColor];
        NSLog(@"垂直");
        //if use Masonry,Please open this annotation
        /*
         [self.playerView mas_updateConstraints:^(MASConstraintMaker *make) {
         make.top.equalTo(self.view).offset(20);
         }];
         */
    }else if (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight || toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
        self.view.backgroundColor = [UIColor redColor];
        //if use Masonry,Please open this annotation
        /*
         [self.playerView mas_updateConstraints:^(MASConstraintMaker *make) {
         make.top.equalTo(self.view).offset(0);
         }];
         */
        NSLog(@"横向");
    }

}




@end
