//
//  A_Controller.m
//  iOS-rotate-demo
//
//  Created by Dvel on 16/4/20.
//  Copyright © 2016年 Dvel. All rights reserved.
//

#import "A_Controller.h"
#import "A_A_ViewController.h"
#import "AppDelegate.h"
@interface A_Controller ()

@end

@implementation A_Controller

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.view.backgroundColor = [UIColor lightTextColor];
	
	UIButton *buttonA = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
	buttonA.backgroundColor = [UIColor blueColor];
	[self.view addSubview:buttonA];
	
	UIButton *buttonB = [[UIButton alloc] initWithFrame:CGRectMake(200, 200, 100, 100)];
	buttonB.backgroundColor = [UIColor redColor];
	[self.view addSubview:buttonB];
    

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    A_A_ViewController *vc = [[A_A_ViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   
}



@end
