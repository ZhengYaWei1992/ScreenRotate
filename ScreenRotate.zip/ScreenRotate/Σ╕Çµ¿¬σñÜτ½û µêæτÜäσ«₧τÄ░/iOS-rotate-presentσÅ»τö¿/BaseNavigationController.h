//
//  BaseNavigationController.h
//  iOS-rotate-demo
//
//  Created by 郑亚伟 on 16/10/14.
//  Copyright © 2016年 Dvel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "A_A_ViewController.h"
@interface BaseNavigationController : UINavigationController
@property(nonatomic)UIInterfaceOrientationMask orietation;
@end
