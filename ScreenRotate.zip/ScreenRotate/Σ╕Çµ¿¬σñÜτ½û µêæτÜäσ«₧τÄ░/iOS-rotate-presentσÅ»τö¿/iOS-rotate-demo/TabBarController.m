//
//  TabBarController.m
//  iOS-rotate-demo
//
//  Created by Dvel on 16/4/20.
//  Copyright © 2016年 Dvel. All rights reserved.
//

#import "TabBarController.h"
#import "A_Controller.h"
#import "A_A_ViewController.h"

@interface TabBarController ()

@end

@implementation TabBarController
//- (BOOL)shouldAutorotate
//{
//    // 获取当前的控制器
//     UINavigationController *navC = self.viewControllers[self.selectedIndex];
//    
//    // 因为默认shouldAutorotate是YES，所以每个不需要支持横屏的控制器都需要重写一遍这个方法
//    // 一般项目中要支持横屏的界面比较少，为了解决这个问题，就取反值：shouldAutorotate返回为YES的时候不能旋转，返回NO的时候可以旋转
//    // 所以只要重写了shouldAutorotate方法的控制器，并return了NO，这个控制器就可以旋转
//    // 当然，如果项目中支持横屏的界面占多数的话，可以不取反值。
////    return !currentVC.shouldAutorotate;
//       //NSLog(@"2222222222");
//    if ([navC.topViewController isKindOfClass:[A_A_ViewController class]] || [navC.topViewController isKindOfClass:[A_Controller class]]) {
//        return YES;
//    }else {
//        return NO;
//    }
//}
//
//- (UIInterfaceOrientationMask)supportedInterfaceOrientations
//{
//    //ZW 这里一定要写为UIInterfaceOrientationMaskAllButUpsideDown 不能写为UIInterfaceOrientationMaskAll因为一般手机支持三个方向，而平板才支持四个方向
//   // NSLog(@"111111111111");
//    UINavigationController *navC = self.selectedViewController;
//    if ([navC.topViewController isKindOfClass:[A_A_ViewController class]]) {
//        return UIInterfaceOrientationMaskLandscape;
//    }else if([navC.topViewController isKindOfClass:[A_Controller class]]){
//        return UIInterfaceOrientationMaskPortrait;
//    }else{
//        return UIInterfaceOrientationMaskPortrait;
//    }
//    //return UIInterfaceOrientationMaskPortrait;
//}
//这个方法并未调用
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
//    NSLog(@"33333333");
//    return UIInterfaceOrientationLandscapeLeft;
//}

//这个方法并未调用
//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
//{
//    NSLog(@"33333333");
//    return UIInterfaceOrientationIsPortrait(interfaceOrientation);
//}


//-(BOOL)shouldAutorotate
//{
//    return YES;
//}
//-(UIInterfaceOrientationMask)supportedInterfaceOrientations
//{
//    return [self.viewControllers.lastObject supportedInterfaceOrientations];
//}
//-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return [self.viewControllers.lastObject preferredInterfaceOrientationForPresentation];
//}


@end
