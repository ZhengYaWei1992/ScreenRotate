//
//  B_Controller.m
//  iOS-rotate-demo
//
//  Created by Dvel on 16/4/20.
//  Copyright © 2016年 Dvel. All rights reserved.
//

#import "B_Controller.h"
#import "B_B_ViewController.h"

@interface B_Controller ()

@end

@implementation B_Controller

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.view.backgroundColor = [UIColor lightGrayColor];
	
	UIButton *buttonA = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
	buttonA.backgroundColor = [UIColor orangeColor];
	[self.view addSubview:buttonA];
	
	UIButton *buttonB = [[UIButton alloc] initWithFrame:CGRectMake(200, 200, 100, 100)];
	buttonB.backgroundColor = [UIColor purpleColor];
	[self.view addSubview:buttonB];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    B_B_ViewController *vc = [[B_B_ViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}
//- (BOOL)shouldAutorotate
//{
//    // 因为是取反值，所以返回NO的控制器，就可以旋转
//    // 因为是取反值，不重写这个方法的控制器，默认就不支持旋转
//    return YES;
//}

@end
